﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr15_v4_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            listBox1.SelectionMode = SelectionMode.MultiExtended;
        }

        List<double[]> arrays = new List<double[]>();
        OneArr mass = new OneArr();
        int count = 0;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown2.Value);
            mass.Dim(n);

            double[] arr = mass.Arr();
            if (arrays.Count < count - 1)
            {
                arrays.Add(arr);
            }
            else
            {
                MessageBox.Show("Все массивы заполнены");
                label2.Enabled = false;
                numericUpDown2.Enabled = false;
                button2.Enabled = false;
            }
            label3.Enabled = true;
            numericUpDown3.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (numericUpDown2.Enabled == false)
            {
                string[] text = mass.Print().Split("\n");

                foreach (var array in text)
                {
                    string j = string.Join(" ", array);

                    listBox1.Items.Add(j);
                }

                label4.Visible = true;
                numericUpDown4.Visible = true;
                label4.Enabled = true;
                numericUpDown4.Enabled = true;
                label3.Visible = true;
                numericUpDown3.Visible = true;
                label1.Enabled = true;
                numericUpDown1.Enabled = true;
                button1.Enabled = true;
                label5.Enabled = true;
                comboBox1.Enabled = true;
            }
            else
            {
                MessageBox.Show("Заполните все массивы");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Enabled == false)
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                mass = new OneArr();
                arrays = new List<double[]>();

                string type = comboBox1.Text;
                mass.Type(type);

                int n = Convert.ToInt32(numericUpDown1.Value);
                count = n;

                label2.Enabled = true;
                numericUpDown2.Enabled = true;
                button2.Enabled = true;
                label2.Visible = true;
                numericUpDown2.Visible = true;
                button2.Visible = true;
                label1.Enabled = false;
                numericUpDown1.Enabled = false;
                button1.Enabled = false;
                button4.Enabled = true;
            }
            else
            {
                MessageBox.Show("Выберите тип данных для массивов");
            }
        }

        private void proizvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double m = Convert.ToInt32(numericUpDown4.Value);
            int n = listBox1.SelectedIndex;

            double[] arr = mass.IndexArr(n, m);
            string text = "";

            foreach (var item in arr)
            {
                text += item + " ";
            }

            listBox2.Items.Add(text);
        }

        private void foreachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown3.Value);
            int m = listBox1.SelectedIndex;
            if (listBox1.SelectedIndex >= 0)
            {
                MessageBox.Show(mass.Index(n, m));
            }
            else
            {
                MessageBox.Show("Выберите массив");
            }
        }

        private void additionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count == 2)
            {
                int firstArr = listBox1.SelectedIndices[0];
                int secondArr = listBox1.SelectedIndices[1];

                string text = mass.Sum(firstArr, secondArr);

                listBox2.Items.Add(text);
            }
            else
            {
                MessageBox.Show("Выберите 2 массива");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label5.Enabled = false;
            comboBox1.Enabled = false;
        }

        private void differenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count == 2)
            {
                int firstArr = listBox1.SelectedIndices[0];
                int secondArr = listBox1.SelectedIndices[1];

                string text = mass.Diff(firstArr, secondArr);

                listBox2.Items.Add(text);
            }
            else
            {
                MessageBox.Show("Выберите 2 массива");
            }
        }
    }
}
