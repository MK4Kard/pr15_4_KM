﻿
namespace pr15_v4_KM
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label2 = new System.Windows.Forms.Label();
            numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            button2 = new System.Windows.Forms.Button();
            label3 = new System.Windows.Forms.Label();
            numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            listBox1 = new System.Windows.Forms.ListBox();
            contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
            proizvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            foreachToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            additionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            button4 = new System.Windows.Forms.Button();
            listBox2 = new System.Windows.Forms.ListBox();
            label1 = new System.Windows.Forms.Label();
            numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            button1 = new System.Windows.Forms.Button();
            label4 = new System.Windows.Forms.Label();
            numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            label5 = new System.Windows.Forms.Label();
            comboBox1 = new System.Windows.Forms.ComboBox();
            differenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(11, 111);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(166, 15);
            label2.TabIndex = 3;
            label2.Text = "Задать размерность массива";
            label2.Visible = false;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new System.Drawing.Point(12, 129);
            numericUpDown2.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new System.Drawing.Size(166, 23);
            numericUpDown2.TabIndex = 4;
            numericUpDown2.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown2.Visible = false;
            // 
            // button2
            // 
            button2.Location = new System.Drawing.Point(185, 128);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(106, 23);
            button2.TabIndex = 5;
            button2.Text = "Задать";
            button2.UseVisualStyleBackColor = true;
            button2.Visible = false;
            button2.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Enabled = false;
            label3.Location = new System.Drawing.Point(300, 10);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(139, 15);
            label3.TabIndex = 6;
            label3.Text = "Найти элемент массива";
            label3.Visible = false;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Enabled = false;
            numericUpDown3.Location = new System.Drawing.Point(300, 28);
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new System.Drawing.Size(195, 23);
            numericUpDown3.TabIndex = 7;
            numericUpDown3.Visible = false;
            // 
            // listBox1
            // 
            listBox1.ContextMenuStrip = contextMenuStrip1;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new System.Drawing.Point(12, 192);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(266, 139);
            listBox1.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { proizvToolStripMenuItem, foreachToolStripMenuItem, additionToolStripMenuItem, differenceToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new System.Drawing.Size(181, 114);
            // 
            // proizvToolStripMenuItem
            // 
            proizvToolStripMenuItem.Name = "proizvToolStripMenuItem";
            proizvToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            proizvToolStripMenuItem.Text = "Proizv";
            proizvToolStripMenuItem.Click += proizvToolStripMenuItem_Click;
            // 
            // foreachToolStripMenuItem
            // 
            foreachToolStripMenuItem.Name = "foreachToolStripMenuItem";
            foreachToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            foreachToolStripMenuItem.Text = "Foreach";
            foreachToolStripMenuItem.Click += foreachToolStripMenuItem_Click;
            // 
            // additionToolStripMenuItem
            // 
            additionToolStripMenuItem.Name = "additionToolStripMenuItem";
            additionToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            additionToolStripMenuItem.Text = "Addition";
            additionToolStripMenuItem.Click += additionToolStripMenuItem_Click;
            // 
            // button4
            // 
            button4.Enabled = false;
            button4.Location = new System.Drawing.Point(12, 163);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(266, 23);
            button4.TabIndex = 10;
            button4.Text = "Вывести изначальный массив";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new System.Drawing.Point(284, 192);
            listBox2.Name = "listBox2";
            listBox2.Size = new System.Drawing.Size(290, 139);
            listBox2.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(11, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(154, 15);
            label1.TabIndex = 13;
            label1.Text = "Сколько массивов создать";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new System.Drawing.Point(12, 30);
            numericUpDown1.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new System.Drawing.Size(165, 23);
            numericUpDown1.TabIndex = 14;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(184, 30);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(106, 23);
            button1.TabIndex = 15;
            button1.Text = "Создать";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(300, 57);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(195, 15);
            label4.TabIndex = 22;
            label4.Text = "На какое число умножить массив";
            label4.Visible = false;
            // 
            // numericUpDown4
            // 
            numericUpDown4.Location = new System.Drawing.Point(300, 78);
            numericUpDown4.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new System.Drawing.Size(195, 23);
            numericUpDown4.TabIndex = 23;
            numericUpDown4.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(12, 57);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(106, 15);
            label5.TabIndex = 24;
            label5.Text = "Какой тип данных";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "int", "double" });
            comboBox1.Location = new System.Drawing.Point(13, 76);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new System.Drawing.Size(165, 23);
            comboBox1.TabIndex = 25;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // differenceToolStripMenuItem
            // 
            differenceToolStripMenuItem.Name = "differenceToolStripMenuItem";
            differenceToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            differenceToolStripMenuItem.Text = "Difference";
            differenceToolStripMenuItem.Click += differenceToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(586, 450);
            Controls.Add(comboBox1);
            Controls.Add(label5);
            Controls.Add(numericUpDown4);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(numericUpDown1);
            Controls.Add(label1);
            Controls.Add(listBox2);
            Controls.Add(button4);
            Controls.Add(listBox1);
            Controls.Add(numericUpDown3);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(numericUpDown2);
            Controls.Add(label2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.ToolStripMenuItem proizvToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem foreachToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem additionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem differenceToolStripMenuItem;
    }
}

