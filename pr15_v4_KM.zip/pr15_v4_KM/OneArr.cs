﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace pr15_v4_KM
{
    class OneArr
    {
        private List<double[]> arrays = new List<double[]>();
        private int dimension;
        private string type;
        Random rnd = new Random();

        public double[] Arr()
        {
            double[] arr = new double[dimension];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Math.Round((rnd.NextDouble() * 100), 2);

                if (type == "int")
                {
                    arr[i] = Convert.ToInt32(arr[i]);
                }
            }

            arrays.Add(arr);

            return arr;
        }

        public void Dim(int n)
        {
            dimension = n;
        }

        public void Type(string t)
        {
            type = t;
        }

        public string Print()
        {
            string text = "";

            foreach (var n in arrays)
            {
                foreach (var i in n)
                {
                    text += i + " ";
                }
                text += "\n";
            }

            return text;
        }

        public string Index(int n, int index)
        {
            double[] arr = arrays[index];
            
            if (n <= arr.Length || n >= 0)
            {
                return arr[n].ToString();
            }
            else
            {
                return "Находимый индекс находился за границей";
            }
        }

        public double[] IndexArr(int n, double m)
        {
            double[] arr = arrays[n];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] *= m;
            }

            return arr;
        }

        public string Sum(int arr1, int arr2)
        {
            double[] first = arrays[arr1];
            double[] second = arrays[arr2];

            string text = "";

            if (first.Length == second.Length)
            {

                double[] sumArr = new double[first.Length];

                for (int i = 0; i < sumArr.Length; i++)
                {
                    sumArr[i] = Math.Round((first[i]), 2, MidpointRounding.AwayFromZero) + Math.Round((second[i]), 2, MidpointRounding.AwayFromZero);
                }

                foreach (var n in sumArr)
                {
                    text += n.ToString() + " ";
                }

                return text;
            }
            else
            {
                return "У массивов разная длина";
            }
        }

        public string Diff(int arr1, int arr2)
        {
            double[] first = arrays[arr1];
            double[] second = arrays[arr2];

            string text = "";

            if (first.Length == second.Length)
            {

                double[] diffArr = new double[first.Length];

                for (int i = 0; i < diffArr.Length; i++)
                {
                    diffArr[i] = Math.Round((first[i]), 2, MidpointRounding.AwayFromZero) - Math.Round((second[i]), 2, MidpointRounding.AwayFromZero);
                }

                foreach (var n in diffArr)
                {
                    text += n.ToString() + " ";
                }

                return text;
            }
            else
            {
                return "У массивов разная длина";
            }
        }
    }
}
